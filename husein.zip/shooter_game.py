from pygame import *
from random import randint

mixer.init()
mixer.music.load('space.ogg')
mixer.music.play()
fire_sound = mixer.Sound('fire.ogg')

font.init()
font1 = font.Font(None, 80)
win = font1.render('YOU WIN!', True, (255, 255, 255))
lose = font1.render('YOU LOSE', True, (180, 0, 0))
font2 = font.Font(None, 36)

#background
img_back = "galaxy.jpg" #game background
img_hero = "rocket.png" #Hero
img_bullet = "bullet.png" #bullet
img_enemy = "asteroid.png" #Enemy

score = 0 
lost = 0 
max_lost = 3
max_score = 10